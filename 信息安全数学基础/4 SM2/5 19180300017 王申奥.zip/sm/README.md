# sm2
A simple implementation of SM2 based on the prime field
